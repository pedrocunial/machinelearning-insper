double drandom();
void seed(double low_in, double hi_in);

